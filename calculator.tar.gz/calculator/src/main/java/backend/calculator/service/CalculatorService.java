package backend.calculator.service;

import org.springframework.stereotype.Service;

import backend.calculator.dto.CalculatorDto;
import backend.calculator.dto.CalculatorResponseDto;
import backend.calculator.enums.Operators;
import backend.calculator.repository.CalculatorRepository;

@Service
public class CalculatorService {
    private final CalculatorRepository repository = new CalculatorRepository();

    public CalculatorResponseDto getCounter() {
        CalculatorResponseDto response = new CalculatorResponseDto();

        Double counter = repository.getCounter();

        response.setSuccess(true);
        response.setResult(counter);

        return response;
    }

    public CalculatorResponseDto resetCounter() {
        CalculatorResponseDto response = new CalculatorResponseDto();

        repository.setCounter(0.0);

        response.setSuccess(true);
        response.setResult(0.0);

        return response;
    }

    public CalculatorResponseDto sum(CalculatorDto calculatorDto) {
        CalculatorResponseDto response = new CalculatorResponseDto();

        Double firstNum = calculatorDto.first_num;
        Double secondNum = calculatorDto.second_num;
        Operators operator = calculatorDto.operator;

        Double result;

        switch (operator) {
            case SUM:
                result = firstNum + secondNum;
                break;
            case SUBTRACTION:
                result = firstNum - secondNum;
                break;
            case MULTIPLICATION:
                result = firstNum * secondNum;
                break;
            case DIVISION:
                result = firstNum / secondNum;
            default:
                response.success = false;
                response.result = 0.0;
        }

        response.success = true;
        response.result = 
    }
}
