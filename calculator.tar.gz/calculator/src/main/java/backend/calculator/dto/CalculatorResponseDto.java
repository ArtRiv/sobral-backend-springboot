package backend.calculator.dto;

public class CalculatorResponseDto {
    public Boolean success;
    public Double result;

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public void setResult(Double result) {
        this.result = result;
    }
}
