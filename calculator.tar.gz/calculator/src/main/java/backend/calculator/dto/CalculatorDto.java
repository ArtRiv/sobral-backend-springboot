package backend.calculator.dto;

import backend.calculator.enums.Operators;

public class CalculatorDto {
    public Double first_num;
    public Double second_num;
    public Operators operator;

    public void setFirstNum(Double num) {
        this.first_num = num;
    }

    public void setSecondNum(Double num) {
        this.second_num = num;
    }

    public void setOperator(Operators operator) {
        this.operator = operator;
    }
}
