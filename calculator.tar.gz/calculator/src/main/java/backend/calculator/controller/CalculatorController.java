package backend.calculator.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import backend.calculator.dto.CalculatorDto;
import backend.calculator.dto.CalculatorResponseDto;
import backend.calculator.service.CalculatorService;

@RestController
@RequestMapping("calculadora")
public class CalculatorController {
    private final CalculatorService service = new CalculatorService();

    @GetMapping()
    public ResponseEntity<CalculatorResponseDto> getCount() {
        return ResponseEntity.status(200).body(service.getCounter());
    }

    @PutMapping("reinicio")
    public ResponseEntity<CalculatorResponseDto> resetCount() {
        return ResponseEntity.status(200).body(service.resetCounter());
    }

    @PutMapping("soma")
    public ResponseEntity<CalculatorResponseDto> sum(@RequestBody CalculatorDto calculatorDto) {
        return ResponseEntity.status(200).body(service.sum(calculatorDto));
    }
}