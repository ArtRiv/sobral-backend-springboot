package backend.calculator.repository;

public class CalculatorRepository {
    Double counter;

    public Double getCounter() {
        return counter;
    }

    public void setCounter(Double counter) {
        this.counter = counter;
    }
}
