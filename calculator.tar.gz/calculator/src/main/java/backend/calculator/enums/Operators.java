package backend.calculator.enums;

public enum Operators {
    SUM,
    SUBTRACTION,
    MULTIPLICATION,
    DIVISION
}